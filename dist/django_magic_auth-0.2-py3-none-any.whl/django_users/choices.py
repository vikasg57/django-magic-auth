class StateStatuses:
    ACTIVE = 0
    INACTIVE = 1


STATE_CHOICES = (
    (StateStatuses.ACTIVE, "ACTIVE"),
    (StateStatuses.INACTIVE, "INACTIVE")
)
